import numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad
import donorvar as dv
from donorvar import simulate


def test_size_shape_identity():
    rng = np.random.default_rng(0)
    a, b = rng.normal(size=50), rng.normal(size=50)
    m, s = dv.mag_shape(a, b)
    assert np.isclose(m + s, np.sum((a - b) ** 2))


def _pair_means(res):
    return np.mean([r["size"] for r in res]), np.mean([r["shape"] for r in res])


def test_null_equal_cells_no_spurious_shape():
    rng = np.random.default_rng(1)
    halves, info = simulate.screen(rng, truth="null", cells=(200, 201))
    # strongest condition (high signal-to-noise): shape and size near zero
    strongest = max(range(20), key=lambda c: np.mean([halves[d][c][0] @ halves[d][c][1] for d in halves]))
    size, shape = _pair_means(dv.size_shape({d: halves[d][strongest] for d in halves}, "cross"))
    assert abs(shape) < 0.05 and abs(size) < 0.05
    # every condition: no difference between the high-score group and the others (no false group effect)
    gaps = []
    for c in range(20):
        res = dv.size_shape({d: halves[d][c] for d in halves}, "cross")
        dev = {d: np.mean([r["shape"] for r in res if d in (r["donor_d"], r["donor_e"])]) for d in halves}
        gaps.append(np.mean([dev[d] for d in dev if info[d]["high"]]) - np.mean([dev[d] for d in dev if not info[d]["high"]]))
    assert abs(np.mean(gaps)) < 0.05


def test_size_truth_recovered_as_size():
    rng = np.random.default_rng(2)
    halves, info = simulate.screen(rng, truth="size", cells=(300, 301), size_sd=0.5)
    c0 = {d: halves[d][0] for d in halves}
    size, shape = _pair_means(dv.size_shape(c0, "cross"))
    assert size > 0.05 and size > 3 * abs(shape)


def test_well_noise_energy():
    rng = np.random.default_rng(3); G, sd = 400, 0.2
    wells = {}
    for w in range(6):
        eff = rng.normal(0, sd, G)
        wells[w] = (eff + rng.normal(0, 0.1, G), eff + rng.normal(0, 0.1, G))
    r = dv.well_noise(wells)
    assert abs(r["well_energy"] - G * sd ** 2) / (G * sd ** 2) < 0.3 and r["ratio"] > 1


def test_shared_well_effect_passes_donor_null_but_matches_technical_baseline():
    rng = np.random.default_rng(4); G = 300; donors = [f"D{i}" for i in range(10)]; cts = ["T", "B", "M"]
    def condition(real):
        shared = rng.normal(size=G) if real else np.zeros(G)
        out = {ct: {} for ct in cts}
        for d in donors:
            well = rng.normal(0, 1, G)            # one well per donor x condition, shared by all cell types
            for ct in cts:
                out[ct][d] = shared + well + rng.normal(0, 1, G)
        return out
    results = []
    for name, real in [("inert1", False), ("inert2", False), ("inert3", False), ("cyto1", True), ("cyto2", True)]:
        r = dv.coordination(condition(real), n_perm=100)
        results.append(dict(condition=name, **r))
    assert all(r["p"] < 0.05 for r in results)              # every condition, including inert, "passes"
    tb = dv.technical_baseline(results, {"inert1", "inert2", "inert3"})
    assert tb["technical_share"] > 0.5                      # most of the excess is technical


def test_pseudo_response_is_coordinated():
    rng = np.random.default_rng(5); G = 300
    prof = {ct: {} for ct in ["T", "B", "M"]}
    for d in range(8):
        well_eff = {w: rng.normal(0, 1, G) for w in range(6)}
        for ct in prof:
            prof[ct][d] = {w: well_eff[w] + rng.normal(0, 1, G) for w in range(6)}
    pr = dv.pseudo_response(prof, [0, 1, 2], [3, 4, 5])
    r = dv.coordination(pr, n_perm=100)
    assert r["excess"] > 0.1 and r["p"] < 0.05


def test_build_pseudobulk_uses_raw_counts_and_responses(tmp_path):
    rng = np.random.default_rng(6); G = 50
    rows, X = [], []
    for d in ["D1", "D2", "D3"]:
        for c in ["PBS", "I1", "I2", "I3", "CYT"]:
            n = 60
            lam = np.full(G, 2.0); lam[:5] *= (3 if c == "CYT" else 1)
            X.append(rng.poisson(lam, (n, G))); rows += [dict(donor=d, ct="T", cond=c)] * n
    counts = sp.csr_matrix(np.vstack(X).astype(np.float32))
    obs = pd.DataFrame(rows); obs.index = obs.index.astype(str)
    a = ad.AnnData(counts, obs=obs, var=pd.DataFrame(index=[f"g{i}" for i in range(G)]))
    a.raw = a.copy(); a.X = sp.csr_matrix(np.log1p(counts.toarray()))      # log in X, counts in raw
    f = tmp_path / "t.h5ad"; a.write_h5ad(f)
    tab = dv.build_pseudobulk(str(f), ["donor", "ct", "cond"], verbose=False)
    v, n = tab.counts(("D1", "T", "PBS"))
    assert n == 60 and np.allclose(v, counts[:60].toarray().sum(0))
    tab.save(tmp_path / "pb.npz"); tab2 = dv.PseudobulkTable.load(str(tmp_path / "pb.npz"))
    assert np.allclose(tab2.counts(("D1", "T", "PBS"))[0], v)
    r = dv.responses(tab, ("D1", "T"), ["CYT", "I1"], reference=["I1", "I2", "I3"], min_cells_half=10)
    assert set(r) == {"CYT", "I1"}
    tgt = dv.common_target(tab, [("D1", "T"), ("D2", "T")], ["CYT", "I1", "I2", "I3"], min_cells_half=10)
    assert 10 <= tgt <= 60
    r2 = dv.responses(tab, ("D1", "T"), ["CYT"], reference=["I1", "I2", "I3"], target_cells=tgt, min_cells_half=10)
    assert "CYT" in r2
    assert r["CYT"][0][:5].mean() > 0.5 and abs(r["I1"][0][:5].mean()) < 0.3


def test_signal_energy_separates_response_from_null():
    rng = np.random.default_rng(7)
    halves, _ = simulate.screen(rng, truth="null", cells=(300, 301))
    e_real = dv.signal_energy({d: halves[d][0] for d in halves})
    noise = {d: (rng.normal(0, 0.08, 500), rng.normal(0, 0.08, 500)) for d in range(24)}
    assert e_real > 10 * abs(dv.signal_energy(noise))
