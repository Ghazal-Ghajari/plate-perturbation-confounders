# donorvar

Well-aware measurement of donor-to-donor variation in single-cell perturbation screens.

Plate-based screens (e.g. Parse 10M PBMC cytokines, OP3) typically have **one well per donor x condition**, with all
cell types of that donor in the same well, and control wells in fixed plate positions. This creates technical signal
that looks like donor biology. `donorvar` provides the pieces to measure donor differences while controlling for it.

| Problem | Tool |
|---|---|
| Control wells placed together (e.g. edge row) create a shared shift in every response | `responses(..., reference=[inert conditions])` (leave-one-out mean of inert conditions) |
| Well-to-well noise shared by both halves of a well | `well_noise` on replicate control wells -> `well_energy` |
| Unequal cell numbers bias every estimator | `responses(..., equal_cells=True)` (binomial thinning) |
| Asymmetric noise estimates create spurious donor differences | `size_shape(..., estimator="cross")` (cross-half estimator) |
| Processing batch confounded with donors | `size_shape(..., groups={donor: batch})` (within-batch comparisons) |
| Shared-well effects pass a donor-permuted null | `coordination` + `pseudo_response` + `technical_baseline` |

## Install

```bash
pip install -e .            # from this folder
pip install -e ".[test]" && pytest
```

## Minimal workflow

```python
import donorvar as dv, numpy as np

# 1. pseudobulk per donor x cell type x condition x random half (raw counts found automatically)
tab = dv.build_pseudobulk("screen.h5ad", keys=["donor", "cell_type", "cytokine"])
tab.save("pb.npz")

# 2. responses against inert conditions, with equal cell numbers
INERT = ["Noggin", "Decorin", "PSPN", "EPO", "TPO", "VEGF"]
target = dv.common_target(tab, [(d, "CD4 T") for d in donors], ["IL-2"] + INERT)   # same depth for all donors
halves = {}
for d in donors:
    r = dv.responses(tab, (d, "CD4 T"), ["IL-2"], reference=INERT, target_cells=target)
    if "IL-2" in r: halves[d] = r["IL-2"]

# 3. well noise from replicate control wells (per donor, same cell type) -> well energy
# well_energy[d] = dv.well_noise({w: (half_A, half_B) for w in control_wells})["well_energy"]

# 4. size/shape donor differences, cross-half, within batch
pairs = dv.size_shape(halves, estimator="cross", well=well_energy, groups=batch_of_donor)

# 5. is cross-cell-type coordination above the technical level?
res = [dict(condition=c, **dv.coordination(resp_by_ct[c])) for c in conditions]
print(dv.technical_baseline(res, negative=set(INERT)))
```

`donorvar.simulate.screen` generates screens with known ground truth (identical donors, size-only differences,
shape changes in a subgroup, unequal cells, well noise) to check an analysis before applying it.
