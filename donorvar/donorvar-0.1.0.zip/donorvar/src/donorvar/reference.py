"""Response vectors against a control condition or against the mean of inert conditions."""
from __future__ import annotations
import numpy as np
from .pseudobulk import PseudobulkTable, lognorm
from .estimators import thin


def common_target(table: PseudobulkTable, contexts: list, conditions: list, min_cells_half: int = 20) -> int:
    """Smallest number of cells per half over the given contexts (e.g. all donors of one cell type) and
    conditions, ignoring groups below `min_cells_half`. Pass it as `target_cells` to `responses` so that
    every donor is thinned to the same depth (needed for unbiased donor comparisons)."""
    ns = []
    for ctx in contexts:
        for c in conditions:
            for h in (0, 1):
                _, n = table.counts(tuple(ctx) + (c,), h)
                if n >= min_cells_half: ns.append(n)
    if not ns:
        raise ValueError("no group reaches min_cells_half")
    return int(min(ns))


def responses(table: PseudobulkTable, context: tuple, conditions: list, reference: str | list,
              gene_idx=None, equal_cells: bool = True, target_cells: int | None = None,
              min_cells_half: int = 20, seed: int = 0):
    """Half-sample responses for one context (e.g. (donor, cell_type)).

    Parameters
    ----------
    context : the group key without the condition, in the order of `table.keys` minus the condition column
              (the condition must be the last key of the table)
    conditions : conditions to return responses for
    reference : a control condition name (e.g. "PBS"), or a list of inert conditions whose mean is used;
                an inert condition is referenced to the other inert conditions (leave-one-out)
    equal_cells : thin every condition to the same number of cells per half
    target_cells : cells per half to thin to; use `common_target` over all donors so that donors are
                   compared at equal depth. If None, the minimum within this context is used.

    Returns {condition: (response_half_A, response_half_B)} on `gene_idx`.
    """
    rng = np.random.default_rng(seed)
    ref_list = [reference] if isinstance(reference, str) else list(reference)
    needed = set(conditions) | set(ref_list)
    raw = {}
    for c in needed:
        h = [table.counts(tuple(context) + (c,), half) for half in (0, 1)]
        if all(v is not None and n >= min_cells_half for v, n in h):
            raw[c] = h
    if not raw:
        return {}
    target = (target_cells if target_cells is not None else min(n for h in raw.values() for _, n in h)) if equal_cells else None
    if equal_cells:
        raw = {c: h for c, h in raw.items() if all(n >= target for _, n in h)}
    prof = {}
    for c, h in raw.items():
        prof[c] = [lognorm(thin(v, n, target, rng) if equal_cells else v) for v, n in h]
        if gene_idx is not None:
            prof[c] = [p[gene_idx] for p in prof[c]]
    out = {}
    for c in conditions:
        if c not in prof:
            continue
        refs = [prof[r] for r in ref_list if r in prof and r != c]
        if not refs:
            continue
        r = [np.mean([x[h] for x in refs], 0) for h in (0, 1)]
        out[c] = (prof[c][0] - r[0], prof[c][1] - r[1])
    return out
