"""Pseudobulk tables: summed raw counts per group and random half of cells."""
from __future__ import annotations
import numpy as np
import pandas as pd
import scipy.sparse as sp


def lognorm(x: np.ndarray, target: float = 1e4) -> np.ndarray:
    """log(1 + target * x / sum(x)) for one summed count vector."""
    return np.log1p(x / max(float(x.sum()), 1.0) * target)


class PseudobulkTable:
    """Summed counts per group and half.

    Parameters
    ----------
    sums : array (n_groups x n_genes) of summed raw counts
    meta : DataFrame with one row per row of `sums`; must contain the grouping columns, `half` (0/1) and `n_cells`
    genes : gene names
    """

    def __init__(self, sums: np.ndarray, meta: pd.DataFrame, genes):
        self.sums = np.asarray(sums)
        self.meta = meta.reset_index(drop=True)
        self.genes = np.asarray(genes).astype(str)
        self.keys = [c for c in self.meta.columns if c not in ("half", "n_cells")]
        self._index = {}
        for i, row in enumerate(self.meta[self.keys + ["half"]].itertuples(index=False, name=None)):
            self._index[tuple(map(str, row[:-1])) + (int(row[-1]),)] = i

    def counts(self, key: tuple, half: int | None = None):
        """Summed counts and number of cells for a group key (tuple in the order of `self.keys`).
        half=None sums both halves. Returns (vector, n_cells) or (None, 0) if absent."""
        key = tuple(map(str, key))
        halves = [0, 1] if half is None else [half]
        rows = [self._index.get(key + (h,)) for h in halves]
        rows = [r for r in rows if r is not None]
        if not rows:
            return None, 0
        return self.sums[rows].astype(np.float64).sum(0), int(self.meta.loc[rows, "n_cells"].sum())

    def save(self, path: str):
        np.savez(path, sums=self.sums, meta=self.meta.to_numpy(dtype=object),
                 columns=np.array(self.meta.columns, dtype=object), genes=self.genes)

    @classmethod
    def load(cls, path: str) -> "PseudobulkTable":
        z = np.load(path, allow_pickle=True)
        meta = pd.DataFrame(z["meta"].tolist(), columns=list(z["columns"]))
        meta["half"] = meta["half"].astype(int); meta["n_cells"] = meta["n_cells"].astype(int)
        return cls(z["sums"], meta, z["genes"])


def _raw_matrix_reader(path: str):
    """Return (n_obs, n_vars, reader(start, end) -> csr, source) for the raw counts of an .h5ad file.
    Looks for integer counts in raw/X, layers/counts, then X."""
    import h5py
    f = h5py.File(path, "r")
    candidates = [("raw/X", "raw/X"), ("layers/counts", "layers['counts']"), ("X", "X")]
    for loc, name in candidates:
        if loc not in f:
            continue
        g = f[loc]
        if isinstance(g, h5py.Group) and "indptr" in g:
            n_obs, n_vars = (int(v) for v in g.attrs["shape"])
            indptr = g["indptr"][:]
            fmt = g.attrs.get("encoding-type", "csr_matrix")
            if isinstance(fmt, bytes): fmt = fmt.decode()
            if fmt != "csr_matrix":
                continue

            def reader(s, e, g=g, indptr=indptr, n_vars=n_vars):
                lo, hi = indptr[s], indptr[e]
                return sp.csr_matrix((g["data"][lo:hi], g["indices"][lo:hi], indptr[s:e + 1] - lo), shape=(e - s, n_vars))
        else:
            n_obs, n_vars = g.shape

            def reader(s, e, g=g):
                return sp.csr_matrix(g[s:e])
        sample = reader(0, min(200, n_obs)).data
        if sample.size == 0 or np.allclose(sample, np.round(sample)):
            return n_obs, n_vars, reader, name
    raise ValueError("No integer count matrix found in raw/X, layers/counts or X")


def build_pseudobulk(path: str, keys: list[str], obs_filter=None, seed: int = 0, chunk: int = 50_000,
                     gene_names_from: str = "auto", verbose: bool = True) -> PseudobulkTable:
    """Sum raw counts per combination of `keys` (obs columns) and a random half of cells.

    Reads the file in chunks, so it works for large screens. `obs_filter` is an optional boolean array
    (length n_obs) selecting the cells to use.
    """
    import anndata as ad
    a = ad.read_h5ad(path, backed="r")
    obs = a.obs[keys].astype(str)
    n_obs, n_vars, reader, source = _raw_matrix_reader(path)
    if verbose:
        print(f"raw counts from {source}: {n_obs:,} cells x {n_vars:,} genes")
    keep = np.ones(n_obs, bool) if obs_filter is None else np.asarray(obs_filter, bool)
    half = np.random.default_rng(seed).integers(0, 2, n_obs)
    key = pd.Series(list(zip(*[obs[k].to_numpy() for k in keys], half))).where(keep)
    code, uniq = pd.factorize(key)
    code = np.where(keep, code, -1)
    sums = np.zeros((len(uniq), n_vars), np.float32)
    for s in range(0, n_obs, chunk):
        e = min(s + chunk, n_obs)
        c = code[s:e]; m = c >= 0
        if not m.any():
            continue
        X = reader(s, e)
        G = sp.csr_matrix((np.ones(m.sum(), np.float32), (c[m], np.where(m)[0])), shape=(len(uniq), e - s))
        sums += (G @ X).toarray().astype(np.float32)
        if verbose:
            print(f"\r{e:,}/{n_obs:,}", end="")
    if verbose:
        print()
    meta = pd.DataFrame(list(uniq), columns=keys + ["half"])
    meta["n_cells"] = np.bincount(code[code >= 0], minlength=len(uniq))
    genes = a.raw.var_names if (source == "raw/X" and a.raw is not None) else a.var_names
    if len(genes) != n_vars:
        genes = [f"gene_{i}" for i in range(n_vars)]
    return PseudobulkTable(sums, meta, genes)
