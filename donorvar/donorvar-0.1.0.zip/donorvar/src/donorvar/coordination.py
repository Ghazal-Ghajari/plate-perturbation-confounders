"""Cross-cell-type coordination within donors, with the donor-permuted null and a technical baseline.

Caution: when every donor x condition is a single well shared by all cell types, the donor-permuted null
removes shared-well effects, so coordination above that null is not evidence of donor biology.
Compare against `technical_baseline` (negative controls, stimulus-free pseudo-responses).
"""
from __future__ import annotations
import numpy as np
from scipy.stats import rankdata


def _zrank(v):
    r = rankdata(v); r = r - r.mean(); return r / (np.linalg.norm(r) + 1e-12)


def coordination(resp: dict, n_perm: int = 500, seed: int = 0, min_donors: int = 3):
    """Within-donor coordination across cell types for one condition.

    resp : {cell_type: {donor: response vector}}
    Statistic: for each donor, the median Spearman over its available cell-type pairs; then the median over
    donors. Null: donor labels permuted independently within each cell type.
    """
    rng = np.random.default_rng(seed)
    cts = [ct for ct in resp if len(resp[ct]) >= min_donors]
    if len(cts) < 2:
        return None
    dl = {ct: sorted(resp[ct]) for ct in cts}
    pos = {ct: {d: i for i, d in enumerate(dl[ct])} for ct in cts}
    Z = {ct: np.array([_zrank(resp[ct][d]) for d in dl[ct]]) for ct in cts}
    pairs = [(a, b) for i, a in enumerate(cts) for b in cts[i + 1:]]
    C = {(a, b): Z[a] @ Z[b].T for a, b in pairs}
    donors = sorted({d for ct in cts for d in dl[ct]})
    slots = {d: [(a, b) for a, b in pairs if d in pos[a] and d in pos[b]] for d in donors}
    donors = [d for d in donors if slots[d]]
    if len(donors) < 4:
        return None

    def stat(perm):
        return np.median([np.median([C[(a, b)][perm[a][pos[a][d]], perm[b][pos[b][d]]] for a, b in slots[d]])
                          for d in donors])
    obs = stat({ct: np.arange(len(dl[ct])) for ct in cts})
    null = np.array([stat({ct: rng.permutation(len(dl[ct])) for ct in cts}) for _ in range(n_perm)])
    return dict(observed=obs, null_median=float(np.median(null)), excess=obs - float(np.median(null)),
                p=(1 + np.sum(null >= obs)) / (1 + n_perm), n_donors=len(donors), n_cell_types=len(cts))


def pseudo_response(control_profiles: dict, group_a: list, group_b: list) -> dict:
    """Stimulus-free pseudo-response: mean of control wells in group_a minus mean in group_b.

    control_profiles : {cell_type: {donor: {well: profile}}}
    Returns {cell_type: {donor: vector}}, ready for `coordination`. Any coordination found here is technical.
    """
    out = {}
    for ct, dd in control_profiles.items():
        out[ct] = {}
        for d, wells in dd.items():
            a = [wells[w] for w in group_a if w in wells]; b = [wells[w] for w in group_b if w in wells]
            if a and b:
                out[ct][d] = np.mean(a, 0) - np.mean(b, 0)
    return out


def technical_baseline(results: list[dict], negative: set, key: str = "condition"):
    """Compare coordination excess of real conditions with negative controls.

    results : list of dicts with `key`, and `excess` (from `coordination`)
    negative : names of negative-control conditions (e.g. inert cytokines)
    Returns median excess of real and negative conditions, the technical share and the share of real
    conditions above the 95th percentile of the negative controls.
    """
    real = np.array([r["excess"] for r in results if r[key] not in negative])
    neg = np.array([r["excess"] for r in results if r[key] in negative])
    if len(neg) == 0 or len(real) == 0:
        raise ValueError("need both real and negative-control conditions")
    return dict(real_excess=float(np.median(real)), negative_excess=float(np.median(neg)),
                technical_share=float(np.median(neg) / np.median(real)),
                real_above_negative95=float(np.mean(real > np.quantile(neg, 0.95))))
