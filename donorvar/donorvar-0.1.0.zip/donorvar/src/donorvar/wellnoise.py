"""Well-to-well noise from replicate control wells."""
from __future__ import annotations
import numpy as np


def well_noise(well_halves: dict) -> dict:
    """Well-to-well noise from replicate wells of the same condition.

    Parameters
    ----------
    well_halves : {well: (profile_half_A, profile_half_B)} for replicate wells of one context
                  (e.g. the PBS or DMSO wells of one donor and cell type)

    Returns dict with
      within   mean ||A_w - B_w||^2 (sampling noise only)
      between  mean ||A_w - B_v||^2, w != v (sampling + well noise)
      ratio    between / within
      well_noise_frac  (between - within) / between
      well_energy      (between - within) / 2, the energy of one well's noise, to pass to `cross_parts`
    """
    wells = sorted(well_halves)
    if len(wells) < 2:
        raise ValueError("need at least two replicate wells")
    within = np.mean([np.sum((well_halves[w][0] - well_halves[w][1]) ** 2) for w in wells])
    between = np.mean([np.sum((well_halves[w][0] - well_halves[v][1]) ** 2) for w in wells for v in wells if v != w])
    return dict(n_wells=len(wells), within=within, between=between, ratio=between / within,
                well_noise_frac=(between - within) / between, well_energy=max(between - within, 0.0) / 2)
