"""Pseudobulk-level simulated screens with known ground truth (used to validate the estimators)."""
from __future__ import annotations
import numpy as np


def screen(rng: np.random.Generator, truth: str = "null", n_donors: int = 24, n_cond: int = 20, G: int = 500,
           resp_norm: float = 5.0, size_sd: float = 0.4, shape_frac: float = 0.8, cells=(100, 400),
           low_cells_for_high: bool = False, sigma_cell: float = 1.0, well_sd: float = 0.0):
    """Simulate half-sample responses for one cell type.

    truth : "null" (identical donors), "size" (donors differ only in size), "shape_high" (the top quarter of
            donors on a latent score change response shape)
    Returns (halves, info): halves = {donor: {condition: (A, B)}}, info = {donor: dict(score, high, n)}.
    """
    u = rng.normal(size=G); u /= np.linalg.norm(u)
    beta = rng.gamma(2, 1, n_cond); beta /= beta.mean()
    spec = rng.normal(size=(n_cond, G)); spec /= np.linalg.norm(spec, axis=1, keepdims=True)
    Z = beta[:, None] * resp_norm * (np.sqrt(0.75) * u + 0.5 * spec)
    score = rng.normal(size=n_donors); high = score >= np.quantile(score, 0.75)
    halves, info = {}, {}
    for d in range(n_donors):
        Zd = Z.copy()
        if truth == "size":
            Zd = Zd * np.exp(rng.normal(0, size_sd, (n_cond, 1)))
        if truth == "shape_high" and high[d]:
            eta = rng.normal(size=(n_cond, G)); eta /= np.linalg.norm(eta, axis=1, keepdims=True)
            Zd = Zd + shape_frac * np.linalg.norm(Zd, axis=1, keepdims=True) * eta
        n = int(cells[0] * 0.4) if (low_cells_for_high and high[d]) else int(rng.integers(*cells))
        w = rng.normal(0, well_sd, (n_cond, G))
        noise = lambda: rng.normal(0, sigma_cell / np.sqrt(n / 2), (n_cond, G))
        halves[d] = {c: (Zd[c] + w[c] + a, Zd[c] + w[c] + b) for c, (a, b) in enumerate(zip(noise(), noise()))}
        info[d] = dict(score=float(score[d]), high=bool(high[d]), n=n, sigma=sigma_cell)
    return halves, info
