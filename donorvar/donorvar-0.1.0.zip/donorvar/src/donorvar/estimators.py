"""Size/shape split of donor differences and noise-aware estimators.

For two response vectors a and b the squared difference splits exactly:
    ||a - b||^2 = (|a| - |b|)^2  +  2 |a| |b| (1 - cos(a, b))
                  size part         shape part
"""
from __future__ import annotations
import numpy as np


def mag_shape(a: np.ndarray, b: np.ndarray):
    """Exact size/shape split of ||a - b||^2 (works row-wise for 2-D inputs)."""
    na, nb = np.linalg.norm(a, axis=-1), np.linalg.norm(b, axis=-1)
    cos = (a * b).sum(-1) / (na * nb + 1e-12)
    return (na - nb) ** 2, 2 * na * nb * (1 - cos)


def cross_parts(Ad, Bd, Ae, Be, well_d: float = 0.0, well_e: float = 0.0):
    """Cross-half size/shape split between donors d and e.

    Norms and the inner product are built only from independent halves:
        |z_d|^2 ~ A_d . B_d - well_d,   z_d . z_e ~ (A_d . B_e + B_d . A_e) / 2
    so sampling noise cancels in expectation. `well_*` is the energy of noise shared by the two halves
    of a well (from `well_noise`), subtracted from the norms.

    The inner products are unbiased; the size/shape split, a ratio of noisy quantities, keeps a small
    positive shape bias at low signal-to-noise. With equal cell numbers across donors this bias is the
    same for every donor and does not create group differences (validated by simulation).
    """
    nd = np.sqrt(max(float(Ad @ Bd) - well_d, 1e-12))
    ne = np.sqrt(max(float(Ae @ Be) - well_e, 1e-12))
    cos = np.clip((float(Ad @ Be) + float(Bd @ Ae)) / 2 / (nd * ne), -1, 1)
    return (nd - ne) ** 2, 2 * nd * ne * (1 - cos)


def thin(counts: np.ndarray, n_from: int, n_to: int, rng: np.random.Generator) -> np.ndarray:
    """Binomial thinning of summed counts from n_from to n_to cells (approximates downsampling cells)."""
    if n_from <= n_to:
        return np.asarray(counts, np.float64)
    return rng.binomial(np.round(counts).astype(np.int64), n_to / n_from).astype(np.float64)


def size_shape(halves: dict, estimator: str = "cross", well: dict | None = None, groups: dict | None = None,
               energy: float | None = None):
    """Donor-by-donor size/shape deviations.

    Parameters
    ----------
    halves : {donor: (A, B)} response vectors from two random halves of cells (same genes, same condition)
    estimator : "cross" (recommended), "sym" or "asym" (flawed, kept for comparison)
    well : optional {donor: well-noise energy} for the cross estimator
    groups : optional {donor: group label}; if given, donors are compared only within the same group
             (e.g. processing batch or date)
    energy : normalization constant. Default: this condition's own mean response energy, which gives weak
             and strong conditions equal weight (relative differences). Pass a pooled value, e.g. the mean
             `signal_energy` over all conditions of a cell type, to express everything on one common scale.

    Returns a list of dicts (donor_d, donor_e, size, shape), normalized by the typical response energy.
    For "asym", one entry per donor against the mean of the others.
    """
    donors = sorted(halves)
    well = well or {}
    if energy is None and estimator == "cross":
        energy = np.mean([max(float(halves[d][0] @ halves[d][1]) - well.get(d, 0.0), 1e-12) for d in donors])
    elif energy is None:
        energy = np.mean([(halves[d][0] @ halves[d][0] + halves[d][1] @ halves[d][1]) / 2 for d in donors])
    out = []
    if estimator == "asym":
        for d in donors:
            others = [e for e in donors if e != d and (groups is None or groups[e] == groups[d])]
            if not others:
                continue
            m = np.mean([(halves[e][0] + halves[e][1]) / 2 for e in others], 0)
            M, S = mag_shape(halves[d][0], m)
            Mw, Sw = mag_shape(halves[d][0], halves[d][1])
            out.append(dict(donor_d=d, donor_e="others", size=(M - Mw / 2) / energy, shape=(S - Sw / 2) / energy))
        return out
    W = {d: mag_shape(*halves[d]) for d in donors}
    for i, d in enumerate(donors):
        for e in donors[i + 1:]:
            if groups is not None and groups[d] != groups[e]:
                continue
            if estimator == "cross":
                m, s = cross_parts(halves[d][0], halves[d][1], halves[e][0], halves[e][1], well.get(d, 0.0), well.get(e, 0.0))
            elif estimator == "sym":
                m1, s1 = mag_shape(halves[d][0], halves[e][1])
                m, s = m1 - (W[d][0] + W[e][0]) / 2, s1 - (W[d][1] + W[e][1]) / 2
            else:
                raise ValueError("estimator must be 'cross', 'sym' or 'asym'")
            out.append(dict(donor_d=d, donor_e=e, size=m / energy, shape=s / energy))
    return out


def signal_energy(halves: dict, well: dict | None = None) -> float:
    """Mean cross-half response energy over donors, A.B - well energy (an unbiased estimate of |z|^2).
    Use it to keep only conditions with a clear response before `size_shape`: for conditions without a
    response, estimated norms are near zero and the size part is dominated by noise."""
    well = well or {}
    return float(np.mean([float(A @ B) - well.get(d, 0.0) for d, (A, B) in halves.items()]))
