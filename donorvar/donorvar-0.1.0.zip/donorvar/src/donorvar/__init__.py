"""donorvar: well-aware measurement of donor-to-donor variation in single-cell perturbation screens.

Main pieces
-----------
PseudobulkTable     summed counts per group (e.g. donor x cell type x condition [x well]) and random half
build_pseudobulk    build a PseudobulkTable from an AnnData file, in chunks, from raw counts
responses           response vectors against a control or against the mean of inert conditions
size_shape          size/shape split of donor differences (asymmetric, symmetric, cross-half estimators)
well_noise          well-to-well noise from replicate control wells
coordination        cross-cell-type coordination with a donor-permuted null
pseudo_response     stimulus-free negative control built from replicate control wells
simulate            simulated screens with known ground truth
"""
from .pseudobulk import PseudobulkTable, build_pseudobulk, lognorm
from .reference import responses, common_target
from .estimators import size_shape, mag_shape, cross_parts, thin, signal_energy
from .wellnoise import well_noise
from .coordination import coordination, pseudo_response, technical_baseline
from . import simulate

__all__ = ["PseudobulkTable", "build_pseudobulk", "lognorm", "responses", "common_target", "size_shape", "mag_shape",
           "cross_parts", "thin", "signal_energy", "well_noise", "coordination", "pseudo_response", "technical_baseline",
           "simulate"]
__version__ = "0.1.0"
